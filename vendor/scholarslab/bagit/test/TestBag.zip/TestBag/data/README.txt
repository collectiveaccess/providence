The images in this were taken from http://www.scholarslab.org/.
